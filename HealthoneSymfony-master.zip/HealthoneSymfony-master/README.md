# HealthoneSymfony

| email | Password | Role  |
|-----------|----------|-------|
| bo.eamonn@gmail.com     | ch405    | admin |